import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {PatientListComponent } from './patient-list/patient-list.component';
import {CreatePatientComponent} from './create-patient/create-patient.component';
import{UpdatePatientComponent} from './update-patient/update-patient.component';
import{PatientDetailsComponent} from './patient-details/patient-details.component';
import { from } from 'rxjs';
const routes: Routes = [

  { path: '', redirectTo: 'patient', pathMatch: 'full' },
  { path: 'patients', component: PatientListComponent },
  { path: 'add', component: CreatePatientComponent },
  { path: 'update/:id', component: UpdatePatientComponent },
  { path: 'details/:id', component: PatientDetailsComponent },

];







@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
