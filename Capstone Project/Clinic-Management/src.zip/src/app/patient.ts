export class Patient {
    id?: any;
    firstName?: String ;
    lastName?: string ;
    address?: string ;
    active?: boolean ;
}